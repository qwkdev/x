cfg = {
	'name': 'XA',
	'ctxt': 'Made by qwk',
	'font': 1,
	'columns': 2,
	'mg': 'rainbow',
	'border': '─│╭╮╰╯',
	'clr': (255, 0, 0),
	'cg': [(255, 0, 0), (255, 150, 150)],
	'fg': [(0, 0, 255), (120, 0, 255)],
	'ig': [(0, 0, 255), (120, 0, 255)],
	'ic': (255, 255, 255),
	'table': 0,
	'pm': 1
}

import requests as rq
from bs4 import BeautifulSoup
import re
from copy import deepcopy as dc
from qhit import *
import os
import concurrent.futures
from random import choice as rc

with open('data.js', encoding='utf-8') as f:
	jsdata = f.read()
data = {j[0][1:].replace('`', ''): [k.replace('`', '') for k in j[1][:-2].split('`, `')] for j in [i.strip('    ').split(']: [') for i in jsdata.split('\n')[1:-1] if i.strip()[:2] != '//' and i.strip() != '']}

def answer(session: str, max_streak: int | None=None) -> None:
	while True:
		ans = None
		x = rq.get('https://achieve.hashtag-learning.co.uk/assess/question-page/', cookies={'sessionid': session})
		soup = BeautifulSoup(x.content, 'html5lib')
		try:
			csrf = soup.find_all('input', attrs={'name': 'csrfmiddlewaretoken'})[0].get('value')
		except IndexError:
			restart(session)
		qn = [i.text for i in soup.find_all('h5') if i.text[:9] == 'Question '][0][9:].split(' of ')

		try:
			streak = int(soup.select_one('div#streak h5').text.strip())
		except AttributeError:
			streak = 0
		if max_streak is not None and streak >= max_streak:
			tw = os.get_terminal_size()[0]
			sl = len(str(streak)) if len(str(streak)) > 6 else 6
			out = session
			if len(session) > (tw-sl-3):
				out = session[:tw-sl-6]+'...'
			print(f"{' '*(tw-len(out)-sl-3)}{out} \u2502 {streak}")
			return

		# May break
		qhtml = re.sub(r'\s+', ' ', soup.select_one('.card-header.question-card-header.pt-4.pb-4.border-secondary > .row.m-0 > .col').decode_contents()).strip().replace('/>', '>')
		if soup.select_one('#text-answer'):
			for i in data[qhtml]:
				if i[0] == '>':
					ans = i[1:]
					break
			
			y = rq.post('https://achieve.hashtag-learning.co.uk/assess/text-button-clicked/', data={
				'text_answer': ans, 'actual_question': qn[0], 'csrfmiddlewaretoken': csrf
			}, headers={
				"Origin": "https://achieve.hashtag-learning.co.uk",
				"Cookie": f"csrftoken={x.cookies['csrftoken']}; sessionid={session}",
			})
		else:
			buttons, dupkey = {}, None
			buttonl = soup.select_one('.card-body.question-card-body').select('button.btn.btn-assess-choice.btn-block')
			for i in buttonl:
				key = i.find_parent().find_parent().find_parent().select_one('.m-1.pt-5.pb-5.pr-2.pl-2.border.border-info.flex-grow-1').decode_contents().strip().replace('/>', '>')
				if key in buttons: dupkey = dc(key)
				buttons[key] = i.get('id')
			
			if dupkey and data[qhtml][0].split('##id=')[0] == dupkey:
				ans = data[qhtml][0].split('##id=')[1].split('button_')[1]
			else:
				for i in data[qhtml]:
					if i in buttons:
						ans = buttons[i].split('button_')[1];
						break

			y = rq.post('https://achieve.hashtag-learning.co.uk/assess/mc-button-clicked/', data={
				'button_value': ans, 'actual_question': qn[0], 'csrfmiddlewaretoken': csrf
			}, headers={
				"Origin": "https://achieve.hashtag-learning.co.uk",
				"Cookie": f"csrftoken={x.cookies['csrftoken']}; sessionid={session}",
			})

		if ans is None: raise ValueError(f'Answer is None')

		tw = os.get_terminal_size()[0]
		streak = str(streak + (1 if y.ok else 0))
		sl = len(streak) if len(streak) > 6 else 6
		out = f"{y.status_code:>3} \u2502 {qn[0]:>4}/{qn[1]} \u2502 {session}"
		if len(out) > (tw-sl-3):
			out = out[:tw-sl-6]+'...'
		print(f"{out}{' '*(tw-len(out)-sl-3)} \u2502 {streak}")
		if qn[0] == qn[1]:
			restart(session)

def restart(session: str):
	x = rq.get('https://achieve.hashtag-learning.co.uk/assess/course/choose-questions/', cookies={'sessionid': session})
	soup = BeautifulSoup(x.content, 'html.parser')
	csrf = soup.find_all('input', attrs={'name': 'csrfmiddlewaretoken'})[0].get('value')
	qamt = soup.find_all('button', attrs={'class': 'btn achieve-cta-button'})[-1].text.strip().split('All (')[1][:-1]

	# TODO: Condense headers
	rq.post('https://achieve.hashtag-learning.co.uk/assess/course/choose-questions/', data={
		'submit': 'submit', 'questions': qamt, 'csrfmiddlewaretoken': csrf
	}, cookies={
		'sessionid': session, 'csrftoken': x.cookies['csrftoken']
	}, headers={
		"Host": "achieve.hashtag-learning.co.uk",
		"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0",
		"Accept": "application/json, text/javascript, */*; q=0.01",
		"Accept-Language": "en-US,en;q=0.5",
		"Accept-Encoding": "gzip, deflate, br, zstd",
		"Referer": "https://achieve.hashtag-learning.co.uk/assess/question-page/",
		"Content-Length": "117",
		"Origin": "https://achieve.hashtag-learning.co.uk",
		"DNT": "1",
		"Sec-GPC": "1",
		"Connection": "keep-alive",
		"Cookie": f"csrftoken={x.cookies['csrftoken']}; sessionid={session}",
		"Sec-Fetch-Dest": "empty",
		"Sec-Fetch-Mode": "no-cors",
		"Sec-Fetch-Site": "same-origin",
		"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
		"X-CSRFToken": csrf,
		"X-Requested-With": "XMLHttpRequest",
		"Priority": "u=0",
		"Pragma": "no-cache",
		"Cache-Control": "no-cache"
	})

def create_session(email: str, password: str) -> str:
	with rq.session() as rqs:
		x = rqs.get('https://achieve.hashtag-learning.co.uk/accounts/login/')
		soup = BeautifulSoup(x.content, 'html.parser')
		csrf = soup.find_all('input', attrs={'name': 'csrfmiddlewaretoken'})[0].get('value')

		tkn = rqs.post('https://achieve.hashtag-learning.co.uk/accounts/login/', data={
			'csrfmiddlewaretoken': csrf, 'login': email, 'password': password
		}, cookies={
			'csrftoken': x.cookies['csrftoken']
		}, headers={
			"Origin": "https://achieve.hashtag-learning.co.uk",
		})
	return tkn.cookies['sessionid']

def create_account(email: str, password: str, school: str, fname: str='\u2800', lname: str='\u2800') -> tuple:
	print('Creating session...')
	with rq.Session() as rqs:
		print('Getting sign up csrf token...')
		x = rqs.get('https://achieve.hashtag-learning.co.uk/accounts/signup-l/')
		soup = BeautifulSoup(x.content, 'html.parser')
		try: csrf = soup.find_all('input', attrs={'name': 'csrfmiddlewaretoken'})[0].get('value')
		except: print(x.content)

		print('Signing up...')
		signup = rqs.post('https://achieve.hashtag-learning.co.uk/accounts/signup-l/', data={
			'csrfmiddlewaretoken': csrf, 'email': email, 'password1': password, 'password2': password
		}, cookies={
			'csrftoken': x.cookies['csrftoken']
		}, headers={
			"Host": "achieve.hashtag-learning.co.uk",
			"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0",
			"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/png,image/svg+xml,*/*;q=0.8",
			"Accept-Language": "en-US,en;q=0.5",
			"Accept-Encoding": "gzip, deflate, br, zstd",
			"Referer": "https://achieve.hashtag-learning.co.uk/accounts/signup-l/",
			"Content-Type": "application/x-www-form-urlencoded",
			"Content-Length": "163",
			"Origin": "https://achieve.hashtag-learning.co.uk",
			"DNT": "1",
			"Sec-GPC": "1",
			"Connection": "keep-alive",
			"Cookie": f"csrftoken={x.cookies['csrftoken']}",
			"Upgrade-Insecure-Requests": "1",
			"Sec-Fetch-Dest": "document",
			"Sec-Fetch-Mode": "navigate",
			"Sec-Fetch-Site": "same-origin",
			"Sec-Fetch-User": "?1",
			"Priority": "u=0, i"
		})
		if not signup.ok: raise ValueError("Couldn't sign up")

		print('Getting naming csrf token...')
		x = rqs.get('https://achieve.hashtag-learning.co.uk/base/learner-school-account/')
		soup = BeautifulSoup(x.content, 'html.parser')
		try: csrf = soup.find_all('input', attrs={'name': 'csrfmiddlewaretoken'})[0].get('value')
		except: print(x.content)

		print('Naming...')
		setname = rqs.post('https://achieve.hashtag-learning.co.uk/base/learner-school-account/', data={
			'csrfmiddlewaretoken': csrf, 'first_name': fname, 'last_name': lname, 'save-learner-details': 'Save'
		}, cookies={
			'csrftoken': x.cookies['csrftoken'], 'sessionid': rqs.cookies.get_dict()['sessionid']
		}, headers={
			"Host": "achieve.hashtag-learning.co.uk",
			"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0",
			"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/png,image/svg+xml,*/*;q=0.8",
			"Accept-Language": "en-US,en;q=0.5",
			"Accept-Encoding": "gzip, deflate, br, zstd",
			"Referer": "https://achieve.hashtag-learning.co.uk/base/learner-school-account/",
			"Content-Type": "application/x-www-form-urlencoded",
			"Content-Length": "143",
			"Origin": "https://achieve.hashtag-learning.co.uk",
			"DNT": "1",
			"Sec-GPC": "1",
			"Connection": "keep-alive",
			"Cookie": f"csrftoken={x.cookies['csrftoken']}; sessionid={rqs.cookies.get_dict()['sessionid']}",
			"Upgrade-Insecure-Requests": "1",
			"Sec-Fetch-Dest": "document",
			"Sec-Fetch-Mode": "navigate",
			"Sec-Fetch-Site": "same-origin",
			"Sec-Fetch-User": "?1",
			"Priority": "u=0, i",
		})
		if not setname.ok: raise ValueError("Couldn't name")

		print('Getting school joiner csrf token...')
		x = rqs.get('https://achieve.hashtag-learning.co.uk/base/learner-school-account/')
		soup = BeautifulSoup(x.content, 'html.parser')
		try: csrf = soup.find_all('input', attrs={'name': 'csrfmiddlewaretoken'})[0].get('value')
		except: print(x.content)

		print('Checking school code...')
		checksc = rqs.post('https://achieve.hashtag-learning.co.uk/base/check-school-class-code/', data={
			'typed_code': school,
			'csrfmiddlewaretoken': csrf
		}, cookies={
			'csrftoken': x.cookies['csrftoken'], 'sessionid': rqs.cookies.get_dict()['sessionid']
		}, headers={
			"Host": "achieve.hashtag-learning.co.uk",
			"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0",
			"Accept": "application/json, text/javascript, */*; q=0.01",
			"Accept-Language": "en-US,en;q=0.5",
			"Accept-Encoding": "gzip, deflate, br, zstd",
			"Referer": "https://achieve.hashtag-learning.co.uk/base/learner-school-details/",
			"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
			"X-CSRFToken": csrf,
			"X-Requested-With": "XMLHttpRequest",
			"Content-Length": "103",
			"Origin": "https://achieve.hashtag-learning.co.uk",
			"DNT": "1",
			"Sec-GPC": "1",
			"Connection": "keep-alive",
			"Cookie": f"csrftoken={x.cookies['csrftoken']}; sessionid={rqs.cookies.get_dict()['sessionid']}",
			"Sec-Fetch-Dest": "empty",
			"Sec-Fetch-Mode": "cors",
			"Sec-Fetch-Site": "same-origin",
		})
		if checksc.json()['is_valid']:
			print(f'Found school: "{checksc.json()['name']}"')
		else:
			raise ValueError(f"Couldn't find school ({school})")

		print('Joining school...')
		joinschool = rqs.post('https://achieve.hashtag-learning.co.uk/base/learner-school-details/', data={
			'csrfmiddlewaretoken': csrf,
			'school_code_field': school,
			'save-learner-school': 'Save',
		}, cookies={
			'csrftoken': x.cookies['csrftoken'], 'sessionid': rqs.cookies.get_dict()['sessionid']
		}, headers={
			"Host": "achieve.hashtag-learning.co.uk",
			"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0",
			"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/png,image/svg+xml,*/*;q=0.8",
			"Accept-Language": "en-US,en;q=0.5",
			"Accept-Encoding": "gzip, deflate, br, zstd",
			"Referer": "https://achieve.hashtag-learning.co.uk/base/learner-school-details/",
			"Content-Type": "application/x-www-form-urlencoded",
			"Content-Length": "136",
			"Origin": "https://achieve.hashtag-learning.co.uk",
			"DNT": "1",
			"Sec-GPC": "1",
			"Connection": "keep-alive",
			"Cookie": f"csrftoken={x.cookies['csrftoken']}; sessionid={rqs.cookies.get_dict()['sessionid']}",
			"Upgrade-Insecure-Requests": "1",
			"Sec-Fetch-Dest": "document",
			"Sec-Fetch-Mode": "navigate",
			"Sec-Fetch-Site": "same-origin",
			"Sec-Fetch-User": "?1",
			"Priority": "u=0, i",
		})
		if not joinschool.ok: raise ValueError("Couldn't join school")

		print('Getting subjects csrf token...')
		x = rqs.get('https://achieve.hashtag-learning.co.uk/course/learner-courses-at-startup/')
		soup = BeautifulSoup(x.content, 'html.parser')
		try: csrf = soup.find_all('meta', attrs={'name': 'csrf-token'})[0].get('content')
		except: print(x.content)
		
		print('Getting subjects...')
		subjects = [[i.get('id').split('-')[0], i.get('id').split('-')[1], i.select_one('span').text.strip()] for i in [*list(soup.select('div#n5-subjects button')), *list(soup.select('div#h-subjects button'))]]

		print('Adding subjects...')
		for l, i, n in subjects:
			addsub = rqs.post('https://achieve.hashtag-learning.co.uk/course/save-course-selected/', data={
				'is_selected': 'true',
				'level_pk': l,
				'subject_pk': i,
				'csrfmiddlewaretoken': csrf
			}, cookies={
				'csrftoken': x.cookies['csrftoken'], 'sessionid': rqs.cookies.get_dict()['sessionid']
			}, headers={
				"Host": "achieve.hashtag-learning.co.uk",
				"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0",
				"Accept": "*/*",
				"Accept-Language": "en-US,en;q=0.5",
				"Accept-Encoding": "gzip, deflate, br, zstd",
				"Referer": "https://achieve.hashtag-learning.co.uk/course/learner-courses-at-startup/",
				"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
				"X-CSRFToken": csrf,
				"X-Requested-With": "XMLHttpRequest",
				"Content-Length": "126",
				"Origin": "https://achieve.hashtag-learning.co.uk",
				"DNT": "1",
				"Sec-GPC": "1",
				"Connection": "keep-alive",
				"Cookie": f"csrftoken={x.cookies['csrftoken']}; sessionid={rqs.cookies.get_dict()['sessionid']}",
				"Sec-Fetch-Dest": "empty",
				"Sec-Fetch-Mode": "cors",
				"Sec-Fetch-Site": "same-origin",
				"Priority": "u=0",
			})
			if addsub.ok:
				print(f"Added {'Higher' if l == '5' else 'Nat 5'} {n}")
			else:
				print(f"Couldn't add {'Higher' if l == '5' else 'Nat 5'} {n}")

		print('Finishing...')
		rqs.get('https://achieve.hashtag-learning.co.uk/')

	return email, password

def set_subject(session: str, subject: str, level: str='4'):
	x = rq.get('https://achieve.hashtag-learning.co.uk/course/change-achieve-course/', cookies={'sessionid': session})
	soup = BeautifulSoup(x.content, 'html.parser')
	csrf = soup.find_all('meta', attrs={'name': 'csrf-token'})[0].get('content')

	setsub = rq.post('https://achieve.hashtag-learning.co.uk/course/change-achieve-course/', data={
		'csrfmiddlewaretoken': csrf,
		'subject_pk': subject,
		'level_pk': level,
		'referrer': 'https://achieve.hashtag-learning.co.uk/assess/assess-home/',
		'submit': 'learn'
	}, cookies={
		'csrftoken': x.cookies['csrftoken'], 'sessionid': session
	}, headers={
		"Host": "achieve.hashtag-learning.co.uk",
		"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:131.0) Gecko/20100101 Firefox/131.0",
		"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/png,image/svg+xml,*/*;q=0.8",
		"Accept-Language": "en-US,en;q=0.5",
		"Accept-Encoding": "gzip, deflate, br, zstd",
		"Referer": "https://achieve.hashtag-learning.co.uk/course/change-achieve-course/",
		"Content-Type": "application/x-www-form-urlencoded",
		"Origin": "https://achieve.hashtag-learning.co.uk",
		"DNT": "1",
		"Sec-GPC": "1",
		"Connection": "keep-alive",
		"Cookie": f"csrftoken={x.cookies['csrftoken']}; sessionid={session}",
		"Upgrade-Insecure-Requests": "1",
		"Sec-Fetch-Dest": "document",
		"Sec-Fetch-Mode": "navigate",
		"Sec-Fetch-Site": "same-origin",
		"Sec-Fetch-User": "?1",
		"Priority": "u=0, i",
	})
	if not setsub.ok: raise ValueError("Couldn't set subject")

def xa(fun: str | None=None):
	tw = os.get_terminal_size()[0]
	print(padhit(gradient(hit(cfg['name'], cfg['font']), 2, [cfg['clr'], cfg['clr']], use_table=cfg['table']), tw, cfg['pm']))
	print(padhit(gradient(cfg['ctxt'], text_clr=cfg['cg'], use_table=cfg['table']), tw, cfg['pm'])); print()
	if fun: print(gradient(f"-- {fun.upper()} --", text_clr=cfg['fg'], use_table=cfg['table']))

def xai(txt: str='', foo=str) -> str:
	while True:
		resp = input(gradient(f"{txt} > ", text_clr=cfg['fg'], use_table=cfg['table'])+rgb('#', cfg['ic'], use_table=cfg['table']).split('#')[0])
		print('\033[0m', end='', flush=True)
		try: return foo(resp)
		except: pass

def check(txt):
	resp = xai(txt+' [Y/N]').lower() != 'n'
	print(f"\033[1A\033[{len(txt+' [Y/N] > ')}C"+rgb(f"[{'YES' if resp else 'NO'}]", cfg['ic'], use_table=cfg['table']))
	return resp

def acc_gen():
	xa('account generator')
	amt, email, password, school, name, save = xai('amount', int), xai('email (sup. ?#)'), xai('password'), xai('school code'), xai('name (sup. ?#)'), check('save?')

	accs = []
	print('Generating accounts...')
	for i in range(amt):
		remail, rpassword = create_account(''.join([rc('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') if i == '?' else i for i in email]).replace('#', str(i+1)), password, school, '\u2800' if name == '' else ''.join([rc('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') if i == '?' else i for i in name]).replace('#', str(i+1)))
		accs.append(f'{remail}:{rpassword}')

	if save:
		print('Saving accounts...')
		with open('accounts.csv', 'a') as f:
			f.write('\n'.join(accs)+'\n')
	print('Done!')

def session_gen():
	xa('token generator')
	info = []
	if check('use saved?'):
		with open('accounts.csv') as f:
			raw = f.read()
		info = [i.split(':') for i in raw.split('\n') if i != '']
	else:
		info = [[xai('email'), xai('password')]]

	le = ''
	for i in info:
		if len(i[0]) > len(le): le = i[0]
	
	amt = xai('amount per acc', int)
	print('Generating tokens...')
	sessions = []
	for n, acc in enumerate(info):
		for _ in range(amt):
			session = create_session(acc[0], acc[1])
			out = f'{str((n*amt)+_+1):>{len(str(len(info)*amt))}}/{len(info)*amt} \u2502 {acc[0]:<{len(le)}} \u2502 {session}'
			tw = os.get_terminal_size()[0]
			if len(out) > tw:
				out = out[:tw-3]+'...'
			print(out)
			sessions.append(session)
	print('Saving...')
	with open('tokens.txt', 'w') as f:
		f.write('\n'.join(sessions))
	print('Done!')

def subject():
	xa('change subject')
	tokens = []
	if check('use saved?'):
		with open('tokens.txt') as f:
			raw = f.read()
		tokens = [i for i in raw.split('\n') if i != '']
	else:
		tokens = [i.strip() for i in xai('token(s)').split(',') if i != '']
	
	level = '5' if not check('nat 5?') else '4'
	sub = str(xai('subject id', int))
	print('Changing subjects...')
	for n, token in enumerate(tokens):
		try: set_subject(token, sub, level)
		except: return
		out = f'{str(n+1):>{len(str(len(tokens)))}}/{len(tokens)} \u2502 {token}'
		tw = os.get_terminal_size()[0]
		if len(out) > tw:
			out = out[:tw-3]+'...'
		print(out)

def main():
	xa('answer spammer')
	tokens = []
	if check('use saved?'):
		with open('tokens.txt') as f:
			raw = f.read()
		tokens = [i for i in raw.split('\n') if i != '']
	else:
		tokens = [i.strip() for i in xai('token(s)').split(',') if i != '']
	ms = xai('max streak', int)
	ms = None if ms <= 0 else ms

	print('Starting tokens...')
	for n, t in enumerate(tokens):
		restart(t)
		print(f'{str(n+1):>{len(str(len(tokens)))}}/{len(tokens)} \u2502 {t}')
	with concurrent.futures.ThreadPoolExecutor() as executor:
		print('Creating threads...')
		futures = [executor.submit(answer, t, ms) for t in tokens]
		print('Spamming...')
		for future in concurrent.futures.as_completed(futures): future.result()
	print('Done!')

cli_app([('Account Gen', acc_gen), ('Token Gen', session_gen), ('Set Subject', subject), ('Answer Spammer', main)], cfg['columns'], cfg['name'], cfg['ctxt'], cfg['font'], cfg['mg'], 1, border=cfg['border'], use_table=cfg['table'])
