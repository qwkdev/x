QHIT_CLR_ESC = '\uABCD'

import json
import os
from functools import lru_cache
from time import sleep
from threading import Thread
import re
with open('qhit_data.json', encoding='utf-8') as f:
	qhitdata = json.load(f)

qhit_clr_table = [  # all ansi ESC[(3/4)8;5;#m colours
	[0, 0, 0], [128, 0, 0], [0, 128, 0], [128, 128, 0], [0, 0, 128], [128, 0, 128], [0, 128, 128], [192, 192, 192], [128, 128, 128], [255, 0, 0], [0, 255, 0], [255, 255, 0], [0, 0, 255], [255, 0, 255], [0, 255, 255], [255, 255, 255],
	[0, 0, 0], [0, 0, 95], [0, 0, 135], [0, 0, 175], [0, 0, 215], [0, 0, 255], [0, 95, 0], [0, 95, 95], [0, 95, 135], [0, 95, 175], [0, 95, 215], [0, 95, 255], [0, 135, 0], [0, 135, 95], [0, 135, 135], [0, 135, 175], [0, 135, 215], [0, 135, 255], [0, 175, 0], [0, 175, 95], [0, 175, 135], [0, 175, 175], [0, 175, 215], [0, 175, 255], [0, 215, 0], [0, 215, 95], [0, 215, 135], [0, 215, 175], [0, 215, 215], [0, 215, 255], [0, 255, 0], [0, 255, 95], [0, 255, 135], [0, 255, 175], [0, 255, 215], [0, 255, 255], [95, 0, 0], [95, 0, 95], [95, 0, 135], [95, 0, 175], [95, 0, 215], [95, 0, 255], [95, 95, 0], [95, 95, 95], [95, 95, 135], [95, 95, 175], [95, 95, 215], [95, 95, 255], [95, 135, 0], [95, 135, 95], [95, 135, 135], [95, 135, 175], [95, 135, 215], [95, 135, 255], [95, 175, 0], [95, 175, 95], [95, 175, 135], [95, 175, 175], [95, 175, 215], [95, 175, 255], [95, 215, 0], [95, 215, 95], [95, 215, 135], [95, 215, 175], [95, 215, 215], [95, 215, 255], [95, 255, 0], [95, 255, 95], [95, 255, 135], [95, 255, 175], [95, 255, 215], [95, 255, 255], [135, 0, 0], [135, 0, 95], [135, 0, 135], [135, 0, 175], [135, 0, 215], [135, 0, 255], [135, 95, 0], [135, 95, 95], [135, 95, 135], [135, 95, 175], [135, 95, 215], [135, 95, 255], [135, 135, 0], [135, 135, 95], [135, 135, 135], [135, 135, 175], [135, 135, 215], [135, 135, 255], [135, 175, 0], [135, 175, 95], [135, 175, 135], [135, 175, 175], [135, 175, 215], [135, 175, 255], [135, 215, 0], [135, 215, 95], [135, 215, 135], [135, 215, 175], [135, 215, 215], [135, 215, 255], [135, 255, 0], [135, 255, 95], [135, 255, 135], [135, 255, 175], [135, 255, 215], [135, 255, 255], [175, 0, 0], [175, 0, 95], [175, 0, 135], [175, 0, 175], [175, 0, 215], [175, 0, 255], [175, 95, 0], [175, 95, 95], [175, 95, 135], [175, 95, 175], [175, 95, 215], [175, 95, 255], [175, 135, 0], [175, 135, 95], [175, 135, 135], [175, 135, 175], [175, 135, 215], [175, 135, 255], [175, 175, 0], [175, 175, 95], [175, 175, 135], [175, 175, 175], [175, 175, 215], [175, 175, 255], [175, 215, 0], [175, 215, 95], [175, 215, 135], [175, 215, 175], [175, 215, 215], [175, 215, 255], [175, 255, 0], [175, 255, 95], [175, 255, 135], [175, 255, 175], [175, 255, 215], [175, 255, 255], [215, 0, 0], [215, 0, 95], [215, 0, 135], [215, 0, 175], [215, 0, 215], [215, 0, 255], [215, 95, 0], [215, 95, 95], [215, 95, 135], [215, 95, 175], [215, 95, 215], [215, 95, 255], [215, 135, 0], [215, 135, 95], [215, 135, 135], [215, 135, 175], [215, 135, 215], [215, 135, 255], [215, 175, 0], [215, 175, 95], [215, 175, 135], [215, 175, 175], [215, 175, 215], [215, 175, 255], [215, 215, 0], [215, 215, 95], [215, 215, 135], [215, 215, 175], [215, 215, 215], [215, 215, 255], [215, 255, 0], [215, 255, 95], [215, 255, 135], [215, 255, 175], [215, 255, 215], [215, 255, 255], [255, 0, 0], [255, 0, 95], [255, 0, 135], [255, 0, 175], [255, 0, 215], [255, 0, 255], [255, 95, 0], [255, 95, 95], [255, 95, 135], [255, 95, 175], [255, 95, 215], [255, 95, 255], [255, 135, 0], [255, 135, 95], [255, 135, 135], [255, 135, 175], [255, 135, 215], [255, 135, 255], [255, 175, 0], [255, 175, 95], [255, 175, 135], [255, 175, 175], [255, 175, 215], [255, 175, 255], [255, 215, 0], [255, 215, 95], [255, 215, 135], [255, 215, 175], [255, 215, 215], [255, 215, 255], [255, 255, 0], [255, 255, 95], [255, 255, 135], [255, 255, 175], [255, 255, 215], [255, 255, 255], [8, 8, 8], [18, 18, 18], [28, 28, 28], [38, 38, 38], [48, 48, 48], [58, 58, 58], [68, 68, 68], [78, 78, 78], [88, 88, 88], [98, 98, 98], [108, 108, 108], [118, 118, 118], [128, 128, 128], [138, 138, 138], [148, 148, 148], [158, 158, 158], [168, 168, 168], [178, 178, 178], [188, 188, 188], [198, 198, 198], [208, 208, 208], [218, 218, 218], [228, 228, 228], [238, 238, 238]
]
qhit_gradient_presets = {
	'rainbow': [(255, 0, 0), (255, 255, 0), (0, 255, 0), (0, 255, 255), (0, 0, 255), (255, 0, 255), (255, 0, 0)],
	'brainbow': [(255, 0, 0), (255, 255, 0), (0, 255, 0), (0, 255, 255), (0, 0, 255), (255, 0, 255), (255, 0, 0)][::-1]
}

def cls() -> None:
	"""Clears the screen using system commands. (Changes to fit OS)"""
	os.system('cls' if os.name == 'nt' else 'clear')

def ansilen(txt: str) -> int:
    ansi_escape = re.compile(r'\x1B[@-_][0-?]*[ -/]*[@-~]')
    return len(ansi_escape.sub('', txt))

def sliceansi(txt: str, start: int=0, end: int=-1) -> str:
	start, end = start if start >= 0 else ansilen(txt)+start, end if end >= 0 else ansilen(txt)+end
	nai, in_ansi, ansi_esc, resp = 0, False, '\033', ''
	for i in txt:
		if nai >= start:
			resp += i
		if i == ansi_esc: in_ansi = True
		elif in_ansi and i == 'm': in_ansi = False
		elif not in_ansi:
			nai += 1
		if nai == end:
			break
	return resp

def clr(txt: str='?', ri: str='w', fse: int=0) -> str:
	"""Basic wrapper for basic ANSI colour codes"""
	endclr = '\033[0m'
	if fse == 2:
		return endclr
	clrs = 'drgybmcw'
	if len(ri) == 1:
		i = f'1{ri}.'
	elif len(ri) == 2:
		i = f'1{ri}'
	else:
		i = ri
	opclr = f"\033[{i[0]};{int(clrs.index(i[1].lower())) + (30 if i[1].isupper() else 90)}{'' if i[2] == '.' else ';'+str(int(clrs.index(i[2].lower())) + 40)}m"
	if fse == 1:
		return opclr
	return f"{opclr}{txt.replace(endclr, endclr+opclr)}{endclr}"

@lru_cache(maxsize=None)
def rgbtotable(irgb: tuple | list) -> int:
	"""Returns the closest matching ANSI colour ID to the given RGB"""
	return sorted([[sum([abs(i[0]-irgb[0]), abs(i[1]-irgb[1]), abs(i[2]-irgb[2])]), n+16] for n, i in enumerate(qhit_clr_table[16:])])[0][1]

def rgb(text: str, text_clr: tuple=None, bg_clr: tuple=None, bold: bool=False, use_table: bool=False) -> str:
	"""Wrapper for RGB ANSI colour codes"""
	clrcode, endclr = ['1'] if bold else [], '\033[0m'
	if not use_table:
		if text_clr is not None:
			clrcode.extend(['38', '2'])
			clrcode.extend([f'{str(i):0>3}' for i in text_clr])
		if bg_clr is not None:
			clrcode.extend(['48', '2'])
			clrcode.extend([f'{str(i):0>3}' for i in bg_clr])
	else:
		if text_clr is not None:
			clrcode.extend(['38', '5', f'{str(rgbtotable(text_clr)):0>3}'])
		if bg_clr is not None:
			clrcode.extend(['48', '5', f'{str(rgbtotable(bg_clr)):0>3}'])
	opclr = f"\033[{';'.join(clrcode)}m"
	return f"{opclr}{text.replace(endclr, endclr+opclr)}{endclr}"

def gradient(text: str, direction: int=0, text_clr: list[tuple] | str='rainbow', bold: bool=False, interval: int | None=None, use_table: bool=False, auto_escape_ansi=False) -> str:
	"""Wrapper for using ANSI colour codes to create gradients. (Supports multi-line text)"""
	if auto_escape_ansi: text = text.replace('\033[0m', '~{QHIT-ESCAPED-ASNI-STYLING-RESET}~').replace('\033[', QHIT_CLR_ESC+'\033[').replace('~{QHIT-ESCAPED-ASNI-STYLING-RESET}~', '\033[0m'+QHIT_CLR_ESC)
	if type(text_clr) == str and text_clr in qhit_gradient_presets.keys():
		text_clr = qhit_gradient_presets[text_clr]
	text = text.split('\n')
	text_width = max(len(l) for l in text)
	if interval is None:
		match direction:
			case 1:
				interval = int(len(text)/(len(text_clr)-1))
			case 2 | 3:
				interval = int((len(text)+text_width)/(len(text_clr)-1))
			case _:
				interval = int(text_width/(len(text_clr)-1))

	clrs = [text_clr[0]]
	for n, i in enumerate(text_clr[:-1]):
		dif = [list(j) for j in zip(*[[int(((text_clr[n+1][j]-i[j])/interval)*(k+1)) for k in range(interval)] for j in range(3)])]
		for j in dif:
			clrs.append((i[0]+j[0], i[1]+j[1], i[2]+j[2]))

	in_clr_esc = False
	match direction:
		case 1:
			resp = ''
			for n, i in enumerate(text):
				for j in i:
					if j == QHIT_CLR_ESC: in_clr_esc = not in_clr_esc
					elif in_clr_esc: resp += j
					else:
						try: resp += rgb(j, clrs[n], None, bold, use_table)
						except IndexError: resp += rgb(j, text_clr[-1], None, bold, use_table)
				resp += '\n'
			return resp[:-1]
		case 2 | 3:
			resp = ''
			for l, i in enumerate(text):
				for n, j in enumerate(i):
					if j == QHIT_CLR_ESC: in_clr_esc = not in_clr_esc
					elif in_clr_esc: resp += j
					else:
						try: resp += rgb(j, clrs[n+l if direction == 2 else (n+len(text))-l], None, bold, use_table)
						except IndexError: resp += rgb(j, text_clr[-1], None, bold, use_table)
				resp += '\n'
			return resp[:-1]
		case _:
			resp = ''
			for i in text:
				for n, j in enumerate(i):
					if j == QHIT_CLR_ESC: in_clr_esc = not in_clr_esc
					elif in_clr_esc: resp += j
					else:
						try: resp += rgb(j, clrs[n], None, bold, use_table)
						except IndexError: resp += rgb(j, text_clr[-1], None, bold, use_table)
				resp += '\n'
			return resp[:-1]

def clrc(txt, clrs, default='w', auto_escape_ansi=False):
	"""Maps colours to certain characters.
	clrs argument is in this format:
	[character (max 1)][colour as supported by clr() function] separated by commas.
	Example Usage:
	clrc('hello world', 'hr,lg,ob', 'm')
	would return 'hello world' in magenta (default="m"), but with the "h" coloured red (r), the "l"s coloured green (g), and the "o"s coloured blue (b)"""
	clrl = {i[0]: i[1:] for i in clrs.split(',')}
	if auto_escape_ansi: txt = txt.replace('\033[0m', '~{QHIT-ESCAPED-ASNI-STYLING-RESET}~').replace('\033[', QHIT_CLR_ESC+'\033[').replace('~{QHIT-ESCAPED-ASNI-STYLING-RESET}~', '\033[0m'+QHIT_CLR_ESC)

	resp, in_clr_esc = '', False
	for i in txt:
		if i == QHIT_CLR_ESC: in_clr_esc = not in_clr_esc
		elif in_clr_esc: resp += i
		else: resp += clr(i, clrl[i] if i in clrl.keys() else default)
	return resp

def hit(txt, font=0, mobile=False, cs=-1, sa=5, ol=False, codec=None) -> str | list[str]:
	"""Basically built-in FIGLET but with support for custom character replacement, spacing, and backgrounds"""
	if cs == -1: cs = [0, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1][font]
	codec, hitchars, cil = codec if codec is not None else qhitdata[font]['mcodec' if mobile else 'codec'], qhitdata[font]['chars'].lower(), '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
	if ol:
		ot = [[] for _ in range(qhitdata[font]['lines'])]
		for i in txt.lower():
			for j in range(qhitdata[font]['lines']):
				if i in hitchars:
					ot[j].append(qhitdata[font]['data'][j][hitchars.index(i)] + ('0'*cs))
				elif i == ' ':
					ot[j].append('0' * sa)
		return [[''.join([codec[cil.index(k)] for k in j]) for j in i] for i in ot]
	ot = ['' for _ in range(qhitdata[font]['lines'])]
	for i in txt.lower():
		for j in range(qhitdata[font]['lines']):
			if i in hitchars:
				ot[j] += qhitdata[font]['data'][j][hitchars.index(i)] + ('0'*cs)
			elif i == ' ':
				ot[j] += '0' * sa

	return '\n'.join([''.join([codec[cil.index(j)] for j in i]) for i in ot])

def gtxt(txt, ingclrs, gdir=0):
	"""Legacy wrapper for basic, single line ANSI colour gradients, migrate to new gradient() function
	(if you cant support rgb ansi outputs, set use_table=True in gradient())"""
	gclrs, f, clrl = ingclrs.split(','), '', []
	if gdir == 1:
		gclrs = gclrs[:len(txt[0])]
		for i in gclrs:
			clrl.extend([i for _ in range(len(txt[0]) // len(gclrs))])
		clrl.extend([gclrs[-1] for _ in range(len(txt[0]) - len(clrl))])
		for i in txt:
			for n, j in enumerate(i):
				f += f"{clr(j, clrl[n])}"
			f += '\n'
		f = f[:-1]
	elif gdir == 2 or gdir == 3:
		gclrs = gclrs[:len(txt[0])]
		clrl.extend([gclrs[0] for _ in range(len(txt) // 2)])
		for i in gclrs:
			clrl.extend([i for _ in range(len(txt[0]) // len(gclrs))])
		clrl.extend([gclrs[-1] for _ in range(len(txt[0]) - len(clrl))])
		clrl.extend([gclrs[-1] for _ in range(len(txt))])
		for n, i in enumerate(txt):
			for m, j in enumerate(i):
				if gdir == 2:
					f += f"{clr(j, clrl[m+n])}"
				else:
					f += f"{clr(j, clrl[m+(len(txt)-n-1)])}"
			f += '\n'
		f = f[:-1]
	else:
		gclrs = gclrs[:len(txt)]
		for i in gclrs:
			clrl.extend([i for _ in range(len(txt) // len(gclrs))])
		clrl.extend([gclrs[-1] for _ in range(len(txt) - len(clrl))])
		for n, i in enumerate(txt):#
			for j in i:
				f += f"{clr(j, clrl[n])}"
			f += '\n'
		f = f[:-1]
	return f

def ghit(txt, ingclrs, gdir=0, font=0, mobile=False, cs=0, sa=5):
	"""Legacy wrapper for basic ANSI colour gradients, migrate to new gradient() function (supports multi-line text)"""
	return gtxt([''.join(i) for i in hit(txt, font, mobile, cs, sa, True)], ingclrs, gdir)

def padhit(txt: str, width: int, gradient: int | None=None, pad: int=0) -> str:
	"""Multi-line text alignment, with support for ANSI colour output from gradient(), takes padding size from length of the first line"""
	txt = txt.split('\n')
	match gradient:
		case 0:
			tl = int(len(txt[0])/15)
		case 1:
			tl = int(len(txt[0])/24)
		case 2:
			tl = int(len(txt[0])/18)
		case 3:
			tl = int(len(txt[0])/16)
		case _:
			tl = len(txt[0])

	if pad == 1:
		return '\n'.join([f"{' '*(width-tl)}{i}" for i in txt])
	else:
		return '\n'.join([f"{' '*int((width-tl)/2)}{i}{' '*int(width-int((width-tl)/2)-tl)}" for i in txt])

# TODO: VVV WRITE DOCS VVV

def cli_app(functions: list[list[str, object]], columns: int=1, name: str='CLI APP', info: str='MADE BY ...', font: int=0, clrl: list | str='rainbow', direction: int=1, delay: float=0.05, border: str | None='─│╭╮╰╯', function_clr: bool=True, index_clr: int=0, use_table=False) -> None:
	def align2(text: str, where: int | str, width: int, char: str=' ') -> str:
		ftext = text.replace(QHIT_CLR_ESC, '')
		match where:
			case 0 | '^': padtext = f"{ftext:{char}^{width}}"
			case 1 | '>': padtext = f"{ftext:{char}>{width}}"
			case 2 | '<': padtext = f"{ftext:{char}<{width}}"
		return padtext.replace(ftext, text)

	if not function_clr:
		functions = [[f'{QHIT_CLR_ESC}{i[0]}{QHIT_CLR_ESC}', i[1]] for i in functions]

	if border is None: border = '      '
	waiting_cmd, logo_cmd, clrs = True, '', []
	tw, th = os.get_terminal_size()
	tw = int(tw/2)*2  # fixes edge cases with border
	title = [f"{border[2]}{border[0]*(tw-2)}{border[3]}", *[border[1]+i[1:-1]+border[1] for i in padhit(hit(name, font), tw).split('\n')]]
	mfnw = len(max([j[0].replace(QHIT_CLR_ESC, '') for j in functions], key=len))
	def clrrealnum(num: str) -> str:
		return ''.join([f'{str(int(num))[0]}{j}' if m == 1 else f'{QHIT_CLR_ESC}{j}{QHIT_CLR_ESC}' for m, j in enumerate(num.split(str(int(num))[0], 1))])

	match index_clr:
		case 1:  # none
			fl = [f"{QHIT_CLR_ESC}[{str(n+1):0>{len(str(len(functions)))}}]{QHIT_CLR_ESC} {align2(i[0], '<', mfnw)}" for n, i in enumerate(functions)]
		case 2:  # only numbers
			fl = [f"{QHIT_CLR_ESC}[{QHIT_CLR_ESC}{str(n+1):0>{len(str(len(functions)))}}{QHIT_CLR_ESC}]{QHIT_CLR_ESC} {align2(i[0], '<', mfnw)}" for n, i in enumerate(functions)]
		case 3:  # only brackets
			fl = [f"[{QHIT_CLR_ESC}{str(n+1):0>{len(str(len(functions)))}}{QHIT_CLR_ESC}] {align2(i[0], '<', mfnw)}" for n, i in enumerate(functions)]
		case 4:  # only real numbers
			fl = [f"{QHIT_CLR_ESC}[{QHIT_CLR_ESC}{clrrealnum(f'{str(n+1):0>{len(str(len(functions)))}}')}{QHIT_CLR_ESC}]{QHIT_CLR_ESC} {align2(i[0], '<', mfnw)}" for n, i in enumerate(functions)]
		case 5:  # only brackets and real numbers
			fl = [f"[{clrrealnum(f'{str(n+1):0>{len(str(len(functions)))}}')}] {align2(i[0], '<', mfnw)}" for n, i in enumerate(functions)]
		case _:  # full
			fl = [f"[{str(n+1):0>{len(str(len(functions)))}}] {align2(i[0], '<', mfnw)}" for n, i in enumerate(functions)]

	k, m = divmod(len(fl), columns)
	fl = [fl[i*k + min(i, m):(i+1)*k + min(i+1, m)] for i in range(columns)]  # list comp of slices
	fl = [[fl[j][n] for j in range(columns) if n in range(len(fl[j]))] for n in range(len(max(fl, key=len)))]
	match columns:
		case 1: fltext = [align2(i[0], '^', tw) for i in fl]
		case 2: fltext = [f"{align2(i[0], '>', (tw//2)-1)}  {align2(i[1], '<', (tw//2)-1)}" for i in fl]
		case 3: fltext = [f"{align2(i[0], '>', (tw//2)-(len(i[1].replace(QHIT_CLR_ESC, ''))//2)-2)}  {i[1]}  {align2(i[2], '<', (tw//2)-(len(i[1].replace(QHIT_CLR_ESC, ''))//2)-2)}" for i in fl]
		case 4: fltext = [f"{align2(i[0], '>', (tw//2)-len(i[1].replace(QHIT_CLR_ESC, ''))-3)}  {i[1]}  {i[2]}  {align2(i[3], '<', (tw//2)-len(i[2].replace(QHIT_CLR_ESC, ''))-3)}" for i in fl]

	interval = int(len(max(hit(name, font).split('\n'), key=len))/2)+len(title)

	if type(clrl) == str:
		if clrl in qhit_gradient_presets.keys():
			cl = qhit_gradient_presets[clrl]
		else:
			cl = clrl
	elif type(clrl) == tuple:
		cl = rgbtotable(clrl)
	else:
		cl = clrl

	title.extend([f"{border[1]}{' '*(tw-2)}{border[1]}", f"{border[1]}{align2(info, '^', tw-2)}{border[1]}", f"{border[1]}{' '*(tw-2)}{border[1]}"])
	fltext = [f"{border[1]}{i[2 if i[0] == QHIT_CLR_ESC else 1:-2 if i[-1] == QHIT_CLR_ESC else -1]}{' '*(tw-len(i.replace(QHIT_CLR_ESC, ''))-1)}{border[1]}" for i in fltext]
	if type(cl) != str:
		title.extend([*fltext, f"{border[1]}{' '*(tw-2)}{border[1]}", border[1]+f"{'>>':>{(tw//2)-1}}\u28E1"[1:]+border[1]])
		borderafter = (th-len(title))-2
		title.extend([*[f"{border[1]}{' '*(tw-2)}{border[1]}" for _ in range(borderafter)], f"{border[4]}{border[0]*(tw-2)}{border[5]}"])

	if type(cl) == list:
		clrs = [cl[0]]
		for n, i in enumerate(cl[:-1]):
			dif = [list(j) for j in zip(*[[int(((cl[n+1][j]-i[j])/interval)*(k+1)) for k in range(interval)] for j in range(3)])]
			for j in dif:
				clrs.append((i[0]+j[0], i[1]+j[1], i[2]+j[2]))

		clrs *= (tw//len(clrs))+1

		def showlogo():
			nonlocal waiting_cmd, clrs
			first_loop = True
			tl = []
			while waiting_cmd:
				output = [] # appending to list is faster than string concatenation
				if not first_loop: output.append('\033[s')
				output.append(f'\033[{len(title)+len(fltext)}A\r')
				for l, i in enumerate(title):
					n, noclr = 0, 0
					for j in i:
						if j == ' ':
							output.append(' ')
							n += 1
						elif j == '\u28E1':
							n += tw//2
							output.append(f'\033[{(tw//2)}C')
						elif j == QHIT_CLR_ESC:
							noclr = [1, 0][noclr]
						else:
							if noclr:
								output.append(f'\033[1m{j}\033[0m')
							else:
								try: output.append(rgb(j, clrs[n if direction in [0, 2] else n+l], None, True, use_table))
								except IndexError: output.append(rgb(j, clrs[0], None, True, use_table))
							n += 1

					output.append('\n')

				if first_loop:
					output.append(f'\033[{borderafter+2}A\033[{(tw//2)-1}C\033[s')
					first_loop = False
				else:
					output.append('\033[u')

				print(''.join(output), end='', flush=True)

				if direction > 1:
					clrs = [clrs[-1], *clrs[:-1]]
				else:
					clrs = [*clrs[1:], clrs[0]]
				sleep(delay)

		def take_input():
			nonlocal waiting_cmd, logo_cmd
			try:
				logo_cmd = input('')
			except:
				waiting_cmd = False

		while True:
			print('\033[?25l')
			cls()
			waiting_cmd, logo_cmd = True, ''
			slogo = Thread(target=showlogo)
			wfi = Thread(target=take_input)
			slogo.start()
			wfi.start()
			wfi.join()
			waiting_cmd = False
			print('\033[?25h')
			cls()
			if logo_cmd in ['exit', 'quit']: cls(); return
			if logo_cmd == 'reset':
				cli_app(functions, columns, name, info, font, clrl, direction, delay, border, function_clr, index_clr, use_table)
				return
			else:
				try: execf = functions[int(logo_cmd)-1][1]
				except: continue
				cls(); execf(); input('\033['+'9'*99+'B\rPress enter to return...')

	elif type(cl) == str:
		if cl == '': cl = 'w,w,w,w,w'
		cl = cl.split(',')
		if cl[0].isdigit():
			cl = [*[int(i) for i in cl], 15, 15, 15, 15]
		else:
			cl.extend(['w', 'w', 'w', 'w'])
		while True:
			cls()
			b1 = clr(border[1], cl[4])
			print('\n'.join([
				'\033[?25h'+clr(title[0], cl[4]),
				*[b1+clr(i[1:-1], cl[0])+b1 for i in title[1:-3]],
				*[b1+clr(i[1:-1], cl[1])+b1 for i in title[-3:]],
				*[b1+clr(i[1:-1], cl[2])+b1 for i in fltext],
				b1+(' '*(tw-2))+b1,
				b1+clr(f"{'>>':>{(tw//2)-2}}{' '*(tw//2)}", cl[3])+b1,
				*[b1+(' '*(tw-2))+b1 for i in range(th-len(title)-len(fltext)-4)],
				clr(f'{border[4]}{border[0]*(tw-2)}{border[5]}', cl[4])+f'\033[{th-(len(title)+len(fltext)+3)}A\r\033[{(tw//2)-1}C'
			]).replace(QHIT_CLR_ESC, ''), end='', flush=True)
			ci = input('')
			if ci in ['exit', 'quit']: cls(); return
			if ci == 'reset':
				cli_app(functions, columns, name, info, font, clrl, direction, delay, border, function_clr, index_clr, use_table)
				return
			else:
				try: execf = functions[int(ci)-1][1]
				except: continue
				cls(); execf(); input('\033['+'9'*99+'B\rPress enter to return...')

class loading:
	def __init__(self, total: int, format: str='[\u2588\u258C\u2800]') -> None:
		self.total = total
		self.format = format
		self.done = 0
		self.max_len = 60 + (2*len(str(self.total)))

	def print_progress_bar(self) -> None:
		tw, th = os.get_terminal_size()
		percent = (100 / self.total) * self.done
		filled = int(percent // 2)
		print(f"\033[s\033[{th}A\r{self.format[0]}{self.format[1]*filled}{'' if percent >= 100 else (self.format[2] if percent % 2 >= 1 else self.format[3])}{self.format[3]*(50-filled-1)}{self.format[4]} {' ' if int(percent) < 10 else ''}{int(percent)}% [{str(self.done):>{len(str(self.total))}}/{self.total}]\033[1B\033[2K\033[u", end='', flush=True)

	def __enter__(self) -> object:
		cls()
		print('\033[2B', end='', flush=True)
		self.print_progress_bar()
		return self

	def __exit__(self, exc_type, exc_value, traceback) -> None:
		cls()
		print(f"{self.format[0]}{self.format[1]*50}{self.format[4]} 100%", end='', flush=True)

	def __call__(self) -> None:
		self.done += 1
		self.print_progress_bar()

class multiload:
	def __init__(self, total: int, format='[\u2588\u258C\u2800]') -> None:
		self.bars = total
		self.done_bars = 0
		self.format = format

	def __enter__(self) -> object:
		cls()
		return self

	def __exit__(self, exc_type, exc_value, traceback) -> None:
		cls()
		print(f"{self.format[0]}{self.format[1]*50}{self.format[4]} 100%\n"*self.bars, end='', flush=True)

	def __call__(self) -> None:
		self.done_bars += 1
		cls()
		print(f"{self.format[0]}{self.format[1]*50}{self.format[4]} 100%\n"*self.done_bars, end='', flush=True)

	class load:
		def __init__(self, parent: object, total: int) -> None:
			self.parent = parent
			self.total = total
			self.done = 0
			self.max_len = 60 + (2*len(str(self.total)))

		def print_progress_bar(self) -> None:
			tw, th = os.get_terminal_size()
			percent = (100 / self.total) * self.done
			filled, filler, nl = int(percent // 2), ' '*(tw-57), '\n'
			print(f"\033[s\033[{th}A{f'{self.parent.format[0]}{self.parent.format[1]*50}{self.parent.format[4]} 100%{filler}{nl}'*self.parent.done_bars}\r{self.parent.format[0]}{self.parent.format[1]*filled}{'' if percent >= 100 else (self.parent.format[2] if percent % 2 >= 1 else self.parent.format[3])}{self.parent.format[3]*(50-filled-1)}{self.parent.format[4]} {' ' if int(percent) < 10 else ''}{int(percent)}% [{str(self.done):>{len(str(self.total))}}/{self.total}]\033[1B\033[2K\033[u", end='', flush=True)

		def __enter__(self) -> object:
			print('\033[2B', end='', flush=True)
			self.print_progress_bar()
			return self

		def __exit__(self, exc_type, exc_value, traceback) -> None:
			cls()
			print(f"{self.parent.format[0]}{self.parent.format[1]*50}{self.parent.format[4]} 100%", end='', flush=True)

		def __call__(self) -> None:
			self.done += 1
			self.print_progress_bar()
